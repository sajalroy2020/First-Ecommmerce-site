

//**-----------------------Mixitup--------------------------------

var containerEl = document.getElementById('gallary');
var mixer = mixitup(containerEl);
	
//**-----------------------Mixitup--END------------------------------  

